package com.sap.sailing.domain.serialization.test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.sap.sailing.domain.base.configuration.DeviceConfiguration;
import com.sap.sailing.domain.base.configuration.RegattaConfiguration;
import com.sap.sailing.domain.base.configuration.impl.DeviceConfigurationImpl;
import com.sap.sailing.domain.base.configuration.impl.RegattaConfigurationImpl;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.example.DeviceConfigurationSerializer;
import com.sap.sailing.domain.serialization.json.DataJsonObject;

public class DeviceConfigurationSerializerTest {
    
    private DataObjectSerializer<RegattaConfiguration> regattaConfigurationSerializerMock;
    private DeviceConfigurationSerializer serializer;
    
    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        regattaConfigurationSerializerMock = mock(DataObjectSerializer.class);
        serializer = new DeviceConfigurationSerializer(regattaConfigurationSerializerMock);
    }
    
    @Test
    public void testRoundTrip() throws DataDeserializationException {
        DeviceConfigurationImpl expectedConfiguration = new DeviceConfigurationImpl(new RegattaConfigurationImpl());
        expectedConfiguration.setResultsMailRecipient("eins@zwei.de");
        
        DataObject result = serializer.serialize(expectedConfiguration, new DataJsonObject());
        DeviceConfiguration actualConfiguration = serializer.deserialize(result);
        
        Assert.assertEquals(expectedConfiguration.getResultsMailRecipient(), actualConfiguration.getResultsMailRecipient());
    }
    
    @Test
    public void testSerializeWithoutRegattaConfiguration() throws DataDeserializationException {
        DataObject dataObject = mock(DataObject.class);
        DataArray courseAreasArray = mock(DataArray.class);
        DataArray courseNamesArray = mock(DataArray.class);
        when(dataObject.createAndPutArray(DeviceConfigurationSerializer.FIELD_COURSE_AREA_NAMES)).thenReturn(courseAreasArray);
        when(dataObject.createAndPutArray(DeviceConfigurationSerializer.FIELD_BY_VALUE_COURSE_DESIGNER_COURSE_NAMES)).thenReturn(courseNamesArray);
        
        DeviceConfigurationImpl expectedConfiguration = new DeviceConfigurationImpl(null);
        expectedConfiguration.setResultsMailRecipient("eins@zwei.de");
        expectedConfiguration.setAllowedCourseAreaNames(Arrays.asList("a", "b"));
        expectedConfiguration.setByNameDesignerCourseNames(Arrays.asList("c", "d"));
        
        DataObject result = serializer.serialize(expectedConfiguration, dataObject);
        
        verify(result, Mockito.never()).createAndPutObject(DeviceConfigurationSerializer.FIELD_REGATTA_CONFIGURATION);
        verify(courseAreasArray).addAll(Arrays.asList("a", "b"));
        verify(courseNamesArray).addAll(Arrays.asList("c", "d"));
        verify(result).put(DeviceConfigurationSerializer.FIELD_RESULTS_RECIPIENT, "eins@zwei.de");
    }
    
    @Test
    public void testSerializeOnlyRegattaConfiguration() throws DataDeserializationException {
        DataObject dataObject = mock(DataObject.class);
        DataObject regattaObject = mock(DataObject.class);
        when(dataObject.createAndPutObject(DeviceConfigurationSerializer.FIELD_REGATTA_CONFIGURATION)).thenReturn(regattaObject);
        
        RegattaConfiguration regattaConfiguration = mock(RegattaConfiguration.class);
        DeviceConfigurationImpl expectedConfiguration = new DeviceConfigurationImpl(regattaConfiguration);
        
        DataObject result = serializer.serialize(expectedConfiguration, dataObject);
        
        verify(result).createAndPutObject(DeviceConfigurationSerializer.FIELD_REGATTA_CONFIGURATION);
        verifyNoMoreInteractions(result);
        verify(regattaConfigurationSerializerMock).serialize(regattaConfiguration, regattaObject);
    }

}
