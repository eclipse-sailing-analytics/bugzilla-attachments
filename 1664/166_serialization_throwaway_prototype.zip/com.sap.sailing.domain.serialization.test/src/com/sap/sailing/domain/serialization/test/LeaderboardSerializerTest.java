package com.sap.sailing.domain.serialization.test;

import java.util.Collections;

import junit.framework.Assert;

import com.sap.sailing.domain.base.Competitor;
import com.sap.sailing.domain.base.impl.BoatClassImpl;
import com.sap.sailing.domain.base.impl.BoatImpl;
import com.sap.sailing.domain.base.impl.CompetitorImpl;
import com.sap.sailing.domain.base.impl.NationalityImpl;
import com.sap.sailing.domain.base.impl.PersonImpl;
import com.sap.sailing.domain.base.impl.TeamImpl;
import com.sap.sailing.domain.leaderboard.Leaderboard;
import com.sap.sailing.domain.leaderboard.impl.FlexibleLeaderboardImpl;
import com.sap.sailing.domain.leaderboard.impl.LowPoint;
import com.sap.sailing.domain.leaderboard.impl.ThresholdBasedResultDiscardingRuleImpl;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.example.leaderboard.LeaderboardSerializer;
import com.sap.sailing.domain.serialization.example.leaderboard.RaceColumnSerializer;
import com.sap.sailing.domain.serialization.example.leaderboard.ResultDiscardingRuleSerializer;
import com.sap.sailing.domain.test.mock.MockedTrackedRaceWithFixedRank;
import com.sap.sailing.domain.tracking.TrackedRace;

public class LeaderboardSerializerTest extends MongoCompatibilityTest<Leaderboard> {

    @Override
    protected DataObjectSerializer<Leaderboard> getMongoSerializer() {
        return new LeaderboardSerializer(new RaceColumnSerializer(), new ResultDiscardingRuleSerializer());
    }

    @Override
    protected String getOldFormatSerialization() {
        return "{ \"LEADERBOARD_NAME\" : \"TestLeaderboard\" , \"LEADERBOARD_SUPPRESSED_COMPETITOR_IDS\" : [ ] , \"SCORING_SCHEME_TYPE\" : \"LOW_POINT\" , \"LEADERBOARD_COLUMNS\" : [ { \"LEADERBOARD_COLUMN_NAME\" : \"My.First.Race$1\" , \"LEADERBOARD_IS_MEDAL_RACE_COLUMN\" : false , \"RACE_IDENTIFIERS\" : { }} , { \"LEADERBOARD_COLUMN_NAME\" : \"My.First$Race$2\" , \"LEADERBOARD_IS_MEDAL_RACE_COLUMN\" : true , \"RACE_IDENTIFIERS\" : { }}] , \"COURSE_AREA_ID\" :  null  , \"LEADERBOARD_COLUMN_FACTORS\" : { } , \"LEADERBOARD_SCORE_CORRECTIONS\" : { \"My%2EFirst%2ERace$1\" : [ { \"COMPETITOR_ID\" : 123 , \"LEADERBOARD_CORRECTED_SCORE\" : 2.75}]} , \"LEADERBOARD_DISCARDING_THRESHOLDS\" : [ 5 , 8] , \"LEADERBOARD_COMPETITOR_DISPLAY_NAMES\" : [ ]}";
    }

    @Override
    protected Leaderboard getOldFormatObject() {
        final String leaderboardName = "TestLeaderboard";
        final String raceColumnName1 = "My.First.Race$1";
        final String raceColumnName2 = "My.First$Race$2";
        final double correctedPoints = 2.75;
        final int[] discardIndexResultsStartingWithHowManyRaces = new int[] { 5, 8 };
        FlexibleLeaderboardImpl leaderboard = new FlexibleLeaderboardImpl(leaderboardName,
                new ThresholdBasedResultDiscardingRuleImpl(discardIndexResultsStartingWithHowManyRaces),
                new LowPoint(), null);
        Competitor competitor = createCompetitor();
        TrackedRace raceWithOneCompetitor1 = new MockedTrackedRaceWithFixedRank(competitor, /* rank */1, /* started */
        true);
        TrackedRace raceWithOneCompetitor2 = new MockedTrackedRaceWithFixedRank(competitor, /* rank */2, /* started */
        true);
        leaderboard.addRace(raceWithOneCompetitor1, raceColumnName1, /* medalRace */false, leaderboard.getFleet(null));
        leaderboard.addRace(raceWithOneCompetitor2, raceColumnName2, /* medalRace */true, leaderboard.getFleet(null));
        leaderboard.getScoreCorrection().correctScore(competitor, leaderboard.getRaceColumnByName(raceColumnName1),
                correctedPoints);
        return leaderboard;
    }

    private Competitor createCompetitor() {
        Competitor competitor = new CompetitorImpl(123, "$$$Dr. Wolfgang+Hunger$$$", new TeamImpl("STG",
                Collections.singleton(new PersonImpl("$$$Dr. Wolfgang+Hunger$$$", new NationalityImpl("GER"),
                /* dateOfBirth */null, "This is famous Dr. Wolfgang Hunger")), new PersonImpl("Rigo van Maas",
                        new NationalityImpl("NED"),
                        /* dateOfBirth */null, "This is Rigo, the coach")), new BoatImpl("Dr. Wolfgang Hunger's boat",
                new BoatClassImpl("505", /* typicallyStartsUpwind */true), null));
        return competitor;
    }

    @Override
    protected void testDeserializationCompatibility(Leaderboard expectedObject, Leaderboard actualObject) {
        Assert.fail("Not implemented yet");
    }
}
