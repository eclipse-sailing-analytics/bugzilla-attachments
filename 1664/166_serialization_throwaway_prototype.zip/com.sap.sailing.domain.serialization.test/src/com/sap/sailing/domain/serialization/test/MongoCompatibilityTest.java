package com.sap.sailing.domain.serialization.test;

import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.junit.Test;

import com.mongodb.BasicDBObject;
import com.mongodb.util.JSON;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.mongodb.DataMongoObject;

public abstract class MongoCompatibilityTest<T> {

    protected abstract DataObjectSerializer<T> getMongoSerializer();

    /**
     * Your implementation should return a JSON serialization directly taken from the old database.
     */
    protected abstract String getOldFormatSerialization();

    /**
     * Your implementation should return a deserialized representation of
     * {@link MongoCompatibilityTest#getOldFormatSerialization()}.
     */
    protected abstract T getOldFormatObject();

    private DataMongoObject getOldFormatDataObject() {
        String json = getOldFormatSerialization();
        BasicDBObject dbObject = (BasicDBObject) JSON.parse(json);
        return DataMongoObject.wrap(dbObject);
    }

    private void assertCompatible(DataMongoObject result) {
        try {
            Object expectedJson = new JSONParser().parse(getOldFormatSerialization());
            String actualSerialization = result.toString();
            Object actualJson = new JSONParser().parse(actualSerialization);
            Assert.assertEquals("Your serializer won't be compatible to the old database format", expectedJson,
                    actualJson);
        } catch (Exception e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * Checks if your serializer serializes to the same representation as you specified in
     * {@link MongoCompatibilityTest#getOldFormatSerialization()}.
     */
    @Test
    public void testSerializationCompatibility() throws DataDeserializationException {
        DataMongoObject target = getMongoSerializer().serialize(getOldFormatObject(), new DataMongoObject());
        assertCompatible(target);
    }

    /**
     * Checks if your serializer deserializes {@link MongoCompatibilityTest#getOldFormatSerialization()} to an object
     * equal to {@link MongoCompatibilityTest#getOldFormatObject()}
     */
    @Test
    public void testDeserializationCompatibility() throws DataDeserializationException {
        T actualObject = getMongoSerializer().deserialize(getOldFormatDataObject());
        testDeserializationCompatibility(getOldFormatObject(), actualObject);
    }

    /**
     * Check if deserialization is compatible to the old database by comparing the objects
     * 
     * @param expectedObject
     *            return value of {@link MongoCompatibilityTest#getOldFormatObject()}
     * @param actualObject
     *            return value of your serializer when deserializing {@link MongoCompatibilityTest#getOldFormatObject()}
     */
    protected abstract void testDeserializationCompatibility(T expectedObject, T actualObject);

}
