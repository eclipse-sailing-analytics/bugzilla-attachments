package com.sap.sailing.domain.serialization.test;

import org.junit.Assert;

import com.sap.sailing.domain.common.impl.DegreeBearingImpl;
import com.sap.sailing.domain.common.impl.DegreePosition;
import com.sap.sailing.domain.common.impl.KnotSpeedWithBearingImpl;
import com.sap.sailing.domain.common.impl.MillisecondsTimePoint;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.DataObjectFlattingSerializer;
import com.sap.sailing.domain.serialization.example.PositionSerializer;
import com.sap.sailing.domain.serialization.example.WindSerializer;
import com.sap.sailing.domain.tracking.Wind;
import com.sap.sailing.domain.tracking.impl.WindImpl;

public class WindSerializerTest extends MongoCompatibilityTest<Wind> {
    
    @Override
    protected DataObjectSerializer<Wind> getMongoSerializer() {
        return new DataObjectFlattingSerializer<Wind>(new WindSerializer(new PositionSerializer()), WindSerializer.FIELD_POSITION);
    }
    
    @Override
    protected String getOldFormatSerialization() {
        return "{ \"LAT_DEG\" : 123.0 , \"LNG_DEG\" : 45.0 , \"TIME_AS_MILLIS\" : 42 , \"KNOT_SPEED\" : 10.4 , \"DEGREE_BEARING\" : 355.5}";
    }

    @Override
    protected Wind getOldFormatObject() {
        return new WindImpl(new DegreePosition(123, 45), new MillisecondsTimePoint(42), new KnotSpeedWithBearingImpl(10.4, new DegreeBearingImpl(355.5)));
    }
    
    @Override
    protected void testDeserializationCompatibility(Wind expectedObject, Wind actualObject) {
        Assert.assertEquals(expectedObject.getTimePoint(), actualObject.getTimePoint());
        Assert.assertEquals(expectedObject.getKilometersPerHour(), actualObject.getKilometersPerHour(), 0.0001);
        Assert.assertEquals(expectedObject.getPosition().getLatRad(), actualObject.getPosition().getLatRad(), 0.0001);
        Assert.assertEquals(expectedObject.getPosition().getLngRad(), actualObject.getPosition().getLngRad(), 0.0001);
    }
}
