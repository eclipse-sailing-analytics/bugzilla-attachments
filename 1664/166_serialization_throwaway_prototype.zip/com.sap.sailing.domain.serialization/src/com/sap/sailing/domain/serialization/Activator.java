package com.sap.sailing.domain.serialization;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.sap.sailing.domain.base.configuration.DeviceConfiguration;
import com.sap.sailing.domain.base.configuration.impl.DeviceConfigurationImpl;
import com.sap.sailing.domain.base.configuration.impl.RegattaConfigurationImpl;
import com.sap.sailing.domain.common.racelog.RacingProcedureType;
import com.sap.sailing.domain.serialization.example.DeviceConfigurationSerializer;
import com.sap.sailing.domain.serialization.example.RegattaConfigurationSerializer;
import com.sap.sailing.domain.serialization.json.DataJsonObject;
import com.sap.sailing.domain.serialization.mongodb.DataMongoObject;
import com.sap.sailing.mongodb.MongoDBConfiguration;
import com.sap.sailing.mongodb.MongoDBService;

public class Activator implements BundleActivator {

    private static Logger logger = Logger.getLogger("Serialization-Test");
    private DBCollection collection;

    protected DeviceConfigurationImpl createConfiguration() {
        RegattaConfigurationImpl r = new RegattaConfigurationImpl();
        r.setDefaultRacingProcedureType(RacingProcedureType.ESS);
        DeviceConfigurationImpl configuration = new DeviceConfigurationImpl(r);
        configuration.setResultsMailRecipient("bla");
        configuration.setAllowedCourseAreaNames(Arrays.asList("1", "2"));
        return configuration;
    }

    protected DataObjectSerializer<DeviceConfiguration> createDeviceConfigurationSerializer() {
        return new DataObjectFlattingSerializer<DeviceConfiguration>(
                new DeviceConfigurationSerializer(new RegattaConfigurationSerializer()),
                DeviceConfigurationSerializer.FIELD_REGATTA_CONFIGURATION);
    }

    @Override
    public void start(BundleContext context) throws Exception {
        MongoDBConfiguration dbConfiguration = MongoDBConfiguration.getDefaultTestConfiguration();
        MongoDBService service = dbConfiguration.getService();
        Mongo mongo = new Mongo("127.0.0.1", dbConfiguration.getPort());
        DB db = service.getDB();
        
        try {
            collection = db.createCollection("test-config", null);
            collection.drop();
            collection = db.createCollection("test-config", null);
            
            jsonDeviceConfiguration();
            dbDeviceConfiguration();
        } catch (RuntimeException e) {
            logger.log(Level.SEVERE, e.getClass().getSimpleName());
        } finally {
            collection.drop();
            mongo.close();
        }
        System.exit(-1);
    }

    private void jsonDeviceConfiguration() throws DataDeserializationException {
        DeviceConfigurationImpl configuration = createConfiguration();
        DataJsonObject target = new DataJsonObject();

        createDeviceConfigurationSerializer().serialize(configuration, target);

        String resultText = target.getValue().toJSONString();
        logger.log(Level.WARNING, resultText);

        DataJsonObject parsedResult = DataJsonObject.parse(resultText);
        DeviceConfiguration back = createDeviceConfigurationSerializer().deserialize(parsedResult);
        logger.log(Level.SEVERE, back.toString());
    }
    
    private void dbDeviceConfiguration() throws DataDeserializationException, UnknownHostException, MongoException {
        DeviceConfigurationImpl configuration = createConfiguration();
        DataMongoObject target = new DataMongoObject();

        createDeviceConfigurationSerializer().serialize(configuration, target);
        collection.insert(target.getValue());

        DataMongoObject parsedResult = DataMongoObject.wrap(collection.findOne());
        DeviceConfiguration back = createDeviceConfigurationSerializer().deserialize(parsedResult);
        logger.log(Level.SEVERE, back.toString());
    }


    @Override
    public void stop(BundleContext context) throws Exception {
    }

}
