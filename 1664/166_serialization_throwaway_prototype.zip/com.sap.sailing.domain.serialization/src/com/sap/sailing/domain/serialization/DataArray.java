package com.sap.sailing.domain.serialization;

import java.util.List;

public interface DataArray extends List<Object> {

    DataObject createAndAddObject();
    DataArray createAndAddArray();

}
