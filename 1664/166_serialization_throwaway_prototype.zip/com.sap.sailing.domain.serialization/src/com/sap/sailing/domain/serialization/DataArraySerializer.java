package com.sap.sailing.domain.serialization;

public interface DataArraySerializer<T> {
    
    <R extends DataArray> R serialize(T object, R target) throws DataDeserializationException;
    T deserialize(DataArray array) throws DataDeserializationException;

}
