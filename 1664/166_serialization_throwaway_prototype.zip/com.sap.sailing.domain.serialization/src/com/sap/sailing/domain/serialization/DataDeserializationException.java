package com.sap.sailing.domain.serialization;

public class DataDeserializationException extends Exception {
    
    private static final long serialVersionUID = 428954808819970976L;

    public DataDeserializationException() {
        super();
    }

    public DataDeserializationException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataDeserializationException(String message) {
        super(message);
    }

    public DataDeserializationException(Throwable cause) {
        super(cause);
    }
    
    

}
