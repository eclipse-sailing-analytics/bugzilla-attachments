package com.sap.sailing.domain.serialization;

import java.util.Map;

public interface DataObject extends Map<String, Object> {

    /**
     * Puts a new {@link DataArray} at the given field name to this {@link DataObject}.
     */
    public DataArray createAndPutArray(String fieldName);
    
    public DataObject createAndPutObject(String fieldName);

    /**
     * Gets the {@link DataArray} at the given field name.
     * 
     * @throws DataDeserializationException
     *             when there is no {@link DataArray} at this field name.
     */
    public DataArray getArray(String fieldName) throws DataDeserializationException;
    
    public DataObject getObject(String fieldName) throws DataDeserializationException;
    
    public int getInteger(String fieldName) throws DataDeserializationException;
    
    public long getLong(String fieldName) throws DataDeserializationException;

    public double getDouble(String fieldName) throws DataDeserializationException;
    
    public String getString(String fieldName) throws DataDeserializationException;
    
    public boolean getBoolean(String fieldName) throws DataDeserializationException;

}
