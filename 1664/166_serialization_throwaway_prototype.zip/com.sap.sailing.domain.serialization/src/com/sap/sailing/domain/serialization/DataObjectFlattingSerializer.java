package com.sap.sailing.domain.serialization;

public class DataObjectFlattingSerializer<T> implements DataObjectSerializer<T> {
    
    private final String[] fieldNamesToFlatten;
    private final DataObjectSerializer<T> serializer;
    
    public DataObjectFlattingSerializer(DataObjectSerializer<T> serializer, String... fieldNamesToFlatten) {
        this.fieldNamesToFlatten = fieldNamesToFlatten;
        this.serializer = serializer;
    }
    
    @Override
    public <R extends DataObject> R serialize(T object, R target) throws DataDeserializationException {
        R result = serializer.serialize(object, target);
        for (String fieldNameToFlatten : fieldNamesToFlatten) {
            DataObject objectToFlatten = result.getObject(fieldNameToFlatten);
            result.remove(fieldNameToFlatten);
            result.putAll(objectToFlatten);
        }
        return result;
    }

    @Override
    public T deserialize(DataObject object) throws DataDeserializationException {
        for (String fieldNameToFlatten : fieldNamesToFlatten) {
            DataObject flattenedObject = object.createAndPutObject(fieldNameToFlatten);
            flattenedObject.putAll(object);
        }
        T result = serializer.deserialize(object);
        return result;
    }

}
