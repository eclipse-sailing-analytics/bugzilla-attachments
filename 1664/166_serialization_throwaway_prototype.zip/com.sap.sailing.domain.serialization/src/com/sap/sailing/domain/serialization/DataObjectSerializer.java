package com.sap.sailing.domain.serialization;

public interface DataObjectSerializer<T> {
    
    <R extends DataObject> R serialize(T object, R target) throws DataDeserializationException;
    T deserialize(DataObject object) throws DataDeserializationException;

}
