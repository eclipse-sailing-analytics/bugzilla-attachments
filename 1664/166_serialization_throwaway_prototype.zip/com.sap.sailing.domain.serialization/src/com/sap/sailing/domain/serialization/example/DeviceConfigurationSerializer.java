package com.sap.sailing.domain.serialization.example;

import java.util.ArrayList;
import java.util.List;

import com.sap.sailing.domain.base.configuration.DeviceConfiguration;
import com.sap.sailing.domain.base.configuration.RegattaConfiguration;
import com.sap.sailing.domain.base.configuration.impl.DeviceConfigurationImpl;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;

public class DeviceConfigurationSerializer implements DataObjectSerializer<DeviceConfiguration> {
    
    public static final String FIELD_COURSE_AREA_NAMES = "courseAreaNames";
    public static final String FIELD_RESULTS_RECIPIENT = "resultsRecipient";
    public static final String FIELD_BY_VALUE_COURSE_DESIGNER_COURSE_NAMES = "byValueCourseNames";
    public static final String FIELD_REGATTA_CONFIGURATION = "procedures";
    
    private final DataObjectSerializer<RegattaConfiguration> regattaConfigurationSerializer;
    
    public DeviceConfigurationSerializer(DataObjectSerializer<RegattaConfiguration> regattaConfigurationSerializer) {
        this.regattaConfigurationSerializer = regattaConfigurationSerializer;
    }

    @Override
    public <R extends DataObject> R serialize(DeviceConfiguration object, R target) throws DataDeserializationException {
        if (object.getRegattaConfiguration() != null) {
            DataObject inner = target.createAndPutObject(FIELD_REGATTA_CONFIGURATION);
            regattaConfigurationSerializer.serialize(object.getRegattaConfiguration(), inner);
        }

        if (object.getAllowedCourseAreaNames() != null) {
            DataArray courseAreaNames = target.createAndPutArray(FIELD_COURSE_AREA_NAMES);
            courseAreaNames.addAll(object.getAllowedCourseAreaNames());
        }
        
        if (object.getResultsMailRecipient() != null) {
            target.put(FIELD_RESULTS_RECIPIENT, object.getResultsMailRecipient());
        }
        
        if (object.getByNameCourseDesignerCourseNames() != null) {
            DataArray nameArray = target.createAndPutArray(FIELD_BY_VALUE_COURSE_DESIGNER_COURSE_NAMES);
            nameArray.addAll(object.getByNameCourseDesignerCourseNames());
        }
        
        return target;
    }
    
    @Override
    public DeviceConfiguration deserialize(DataObject object) throws DataDeserializationException {
        
        RegattaConfiguration regattaConfiguration = null;
        if (object.containsKey(FIELD_REGATTA_CONFIGURATION)) {
            DataObject proceduresObject = object.getObject(FIELD_REGATTA_CONFIGURATION);
            regattaConfiguration = regattaConfigurationSerializer.deserialize(proceduresObject);
        }
        
        DeviceConfigurationImpl configuration = new DeviceConfigurationImpl(regattaConfiguration);

        if (object.containsKey(FIELD_COURSE_AREA_NAMES)) {
            DataArray courseAreaNames = object.getArray(FIELD_COURSE_AREA_NAMES);
            List<String> allowedCourseAreaNames = new ArrayList<String>();
            for (Object name : courseAreaNames) {
                allowedCourseAreaNames.add(name.toString());
            }
            configuration.setAllowedCourseAreaNames(allowedCourseAreaNames);
        }

        if (object.containsKey(FIELD_RESULTS_RECIPIENT)) {
            configuration.setResultsMailRecipient(object.getString(FIELD_RESULTS_RECIPIENT));
        }

        if (object.containsKey(FIELD_BY_VALUE_COURSE_DESIGNER_COURSE_NAMES)) {
            DataArray namesArray = object.getArray(FIELD_BY_VALUE_COURSE_DESIGNER_COURSE_NAMES);
            List<String> names = new ArrayList<String>();
            for (Object name : namesArray) {
                names.add(name.toString());
            }
            configuration.setByNameDesignerCourseNames(names);
        }

        return configuration;
    }

}
