package com.sap.sailing.domain.serialization.example;

import com.sap.sailing.domain.common.Position;
import com.sap.sailing.domain.common.impl.DegreePosition;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;

public class PositionSerializer implements DataObjectSerializer<Position> {
    
    public static final String FIELD_LATITUDE_DEG = FieldNames.LAT_DEG.name();
    public static final String FIELD_LONGITUDE_DEG = FieldNames.LNG_DEG.name();

    @Override
    public <R extends DataObject> R serialize(Position object, R target) throws DataDeserializationException {
        target.put(FIELD_LATITUDE_DEG, object.getLatDeg());
        target.put(FIELD_LONGITUDE_DEG, object.getLngDeg());
        return target;
    }

    @Override
    public Position deserialize(DataObject object) throws DataDeserializationException {
        double lat = object.getDouble(FIELD_LATITUDE_DEG);
        double lng = object.getDouble(FIELD_LONGITUDE_DEG);
        return new DegreePosition(lat, lng);
    }

}
