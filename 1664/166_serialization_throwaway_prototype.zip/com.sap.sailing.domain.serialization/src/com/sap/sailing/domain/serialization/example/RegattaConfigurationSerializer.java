package com.sap.sailing.domain.serialization.example;

import com.sap.sailing.domain.base.configuration.RegattaConfiguration;
import com.sap.sailing.domain.base.configuration.impl.RegattaConfigurationImpl;
import com.sap.sailing.domain.common.CourseDesignerMode;
import com.sap.sailing.domain.common.racelog.RacingProcedureType;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;

public class RegattaConfigurationSerializer implements DataObjectSerializer<RegattaConfiguration> {

    public static final String FIELD_DEFAULT_RACING_PROCEDURE_TYPE = "defaultRacingProcedureType";
    public static final String FIELD_DEFAULT_COURSE_DESIGNER_MODE = "defaultCourseDesignerMode";
    
    @Override
    public <R extends DataObject> R serialize(RegattaConfiguration object, R target) {
        if (object.getDefaultRacingProcedureType() != null) {
            target.put(FIELD_DEFAULT_RACING_PROCEDURE_TYPE, object.getDefaultRacingProcedureType().name());
        }
        if (object.getDefaultCourseDesignerMode() != null) {
            target.put(FIELD_DEFAULT_COURSE_DESIGNER_MODE, object.getDefaultCourseDesignerMode().name());
        }
        return target;
    }

    @Override
    public RegattaConfiguration deserialize(DataObject object) throws DataDeserializationException {
        RegattaConfigurationImpl configuration = new RegattaConfigurationImpl();
        
        if (object.containsKey(FIELD_DEFAULT_RACING_PROCEDURE_TYPE)) {
            RacingProcedureType type = RacingProcedureType.valueOf(object.getString(
                    FIELD_DEFAULT_RACING_PROCEDURE_TYPE));
            configuration.setDefaultRacingProcedureType(type);
        }

        if (object.containsKey(FIELD_DEFAULT_COURSE_DESIGNER_MODE)) {
            CourseDesignerMode mode = CourseDesignerMode.valueOf(object.getString(
                    FIELD_DEFAULT_COURSE_DESIGNER_MODE));
            configuration.setDefaultCourseDesignerMode(mode);
        }
        
        return configuration;
    }

}
