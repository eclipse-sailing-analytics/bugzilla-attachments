package com.sap.sailing.domain.serialization.example;

import com.sap.sailing.domain.common.Bearing;
import com.sap.sailing.domain.common.Position;
import com.sap.sailing.domain.common.SpeedWithBearing;
import com.sap.sailing.domain.common.impl.DegreeBearingImpl;
import com.sap.sailing.domain.common.impl.KnotSpeedWithBearingImpl;
import com.sap.sailing.domain.common.impl.MillisecondsTimePoint;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.tracking.Wind;
import com.sap.sailing.domain.tracking.impl.WindImpl;

public class WindSerializer implements DataObjectSerializer<Wind> {
    
    public static final String FIELD_POSITION = "position";
    public static final String FIELD_TIMEPOINT = FieldNames.TIME_AS_MILLIS.name();
    public static final String FIELD_SPEED_IN_KNOTS = FieldNames.KNOT_SPEED.name();
    public static final String FIELD_BEARING = FieldNames.DEGREE_BEARING.name();
    
    private final DataObjectSerializer<Position> positionSerializer;

    public WindSerializer(DataObjectSerializer<Position> positionSerializer) {
        this.positionSerializer = positionSerializer;
    }

    @Override
    public <R extends DataObject> R serialize(Wind object, R target) throws DataDeserializationException {
        Position position = object.getPosition();
        if (position != null) {
            positionSerializer.serialize(position, target.createAndPutObject(FIELD_POSITION));
        }
        target.put(FIELD_TIMEPOINT, object.getTimePoint().asMillis());
        target.put(FIELD_SPEED_IN_KNOTS, object.getKnots());
        target.put(FIELD_BEARING, object.getBearing().getDegrees());

        return target;
    }

    @Override
    public Wind deserialize(DataObject object) throws DataDeserializationException {
        Position position = positionSerializer.deserialize(object.getObject(FIELD_POSITION));
        long timeStamp = object.getLong(FIELD_TIMEPOINT);
        SpeedWithBearing speedBearing = deserializeSpeedWithBearing(object);
        return new WindImpl(position, new MillisecondsTimePoint(timeStamp), speedBearing);
    }

    private SpeedWithBearing deserializeSpeedWithBearing(DataObject object) throws DataDeserializationException {
        double direction = 0.0;
        if (object.containsKey(FIELD_BEARING)) {
            direction = object.getDouble(FIELD_BEARING);
        } else {
            direction = object.getDouble("bearing");
        }
        Bearing degreeBearing = new DegreeBearingImpl(direction);
        Number speedInKnots = (Number) object.get(FIELD_SPEED_IN_KNOTS);
        return new KnotSpeedWithBearingImpl(speedInKnots.doubleValue(), degreeBearing);
    }

}
