package com.sap.sailing.domain.serialization.example.leaderboard;

import com.sap.sailing.domain.base.Competitor;
import com.sap.sailing.domain.base.RaceColumn;
import com.sap.sailing.domain.common.MaxPointsReason;
import com.sap.sailing.domain.common.TimePoint;
import com.sap.sailing.domain.common.impl.MillisecondsTimePoint;
import com.sap.sailing.domain.leaderboard.FlexibleLeaderboard;
import com.sap.sailing.domain.leaderboard.Leaderboard;
import com.sap.sailing.domain.leaderboard.RegattaLeaderboard;
import com.sap.sailing.domain.leaderboard.ResultDiscardingRule;
import com.sap.sailing.domain.leaderboard.SettableScoreCorrection;
import com.sap.sailing.domain.leaderboard.ThresholdBasedResultDiscardingRule;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataArraySerializer;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.example.FieldNames;
import com.sap.sailing.domain.serialization.mongodb.DataMongoSerializer;

public class LeaderboardSerializer extends DataMongoSerializer<Leaderboard, String> {

    private final DataObjectSerializer<RaceColumn> raceColumnSerializer;
    private final DataArraySerializer<ResultDiscardingRule> resultDiscardingRuleSerializer;

    public LeaderboardSerializer(DataObjectSerializer<RaceColumn> raceColumnSerializer,
            DataArraySerializer<ResultDiscardingRule> resultDiscardingRuleSerializer) {
        this.raceColumnSerializer = raceColumnSerializer;
        this.resultDiscardingRuleSerializer = resultDiscardingRuleSerializer;
    }

    @Override
    public com.mongodb.DBObject createQuery(String leaderboardName) {
        return new com.mongodb.BasicDBObject(FieldNames.LEADERBOARD_NAME.name(), leaderboardName);
    }

    @Override
    public <R extends DataObject> R serialize(Leaderboard leaderboard, R target) throws DataDeserializationException {
        target.put(FieldNames.LEADERBOARD_NAME.name(), leaderboard.getName());
        if (leaderboard.getDisplayName() != null) {
            target.put(FieldNames.LEADERBOARD_DISPLAY_NAME.name(), leaderboard.getDisplayName());
        }
        DataArray dbSuppressedCompetitorIds = target.createAndPutArray(FieldNames.LEADERBOARD_SUPPRESSED_COMPETITOR_IDS
                .name());
        for (Competitor suppressedCompetitor : leaderboard.getSuppressedCompetitors()) {
            dbSuppressedCompetitorIds.add(suppressedCompetitor.getId());
        }
        target.put(FieldNames.LEADERBOARD_SUPPRESSED_COMPETITOR_IDS.name(), dbSuppressedCompetitorIds);
        if (leaderboard instanceof FlexibleLeaderboard) {
            serializeFlexibleLeaderboard((FlexibleLeaderboard) leaderboard, target);
        } else if (leaderboard instanceof RegattaLeaderboard) {
            serializeRegattaLeaderboard((RegattaLeaderboard) leaderboard, target);
        } else {
            // at least store the scoring scheme
            target.put(FieldNames.SCORING_SCHEME_TYPE.name(), leaderboard.getScoringScheme().getType().name());
        }
        if (leaderboard.getDefaultCourseArea() != null) {
            target.put(FieldNames.COURSE_AREA_ID.name(), leaderboard.getDefaultCourseArea().getId().toString());
        } else {
            target.put(FieldNames.COURSE_AREA_ID.name(), null);
        }

        serializeColumnFactors(leaderboard, target.createAndPutObject(FieldNames.LEADERBOARD_COLUMN_FACTORS.name()));
        serializeLeaderboardCorrectionsAndDiscards(leaderboard, target);
        return target;
    }
    
    private void serializeRegattaLeaderboard(RegattaLeaderboard leaderboard, DataObject target) {
        target.put(FieldNames.REGATTA_NAME.name(), leaderboard.getRegatta().getName());
    }

    private void serializeFlexibleLeaderboard(FlexibleLeaderboard leaderboard, DataObject target)
            throws DataDeserializationException {
        target.put(FieldNames.SCORING_SCHEME_TYPE.name(), leaderboard.getScoringScheme().getType().name());
        DataArray dbRaceColumns = target.createAndPutArray(FieldNames.LEADERBOARD_COLUMNS.name());
        for (RaceColumn raceColumn : leaderboard.getRaceColumns()) {
            raceColumnSerializer.serialize(raceColumn, dbRaceColumns.createAndAddObject());
        }
    }

    private void serializeColumnFactors(Leaderboard leaderboard, DataObject target) {
        for (RaceColumn raceColumn : leaderboard.getRaceColumns()) {
            Double explicitFactor = raceColumn.getExplicitFactor();
            if (explicitFactor != null) {
                target.put(raceColumn.getName(), explicitFactor);
            }
        }
    }

    private void serializeLeaderboardCorrectionsAndDiscards(Leaderboard leaderboard, DataObject target)
            throws DataDeserializationException {
        if (leaderboard.hasCarriedPoints()) {
            DataArray dbCarriedPoints = target.createAndPutArray(FieldNames.LEADERBOARD_CARRIED_POINTS_BY_ID.name());
            for (Competitor competitor : leaderboard.getCompetitors()) {
                if (leaderboard.hasCarriedPoints(competitor)) {
                    DataObject dbCarriedPointsForCompetitor = dbCarriedPoints.createAndAddObject();
                    dbCarriedPointsForCompetitor.put(FieldNames.COMPETITOR_ID.name(), competitor.getId());
                    dbCarriedPointsForCompetitor.put(FieldNames.LEADERBOARD_CARRIED_POINTS.name(),
                            leaderboard.getCarriedPoints(competitor));
                }
            }
        }
        storeScoreCorrections(leaderboard, target.createAndPutObject(FieldNames.LEADERBOARD_SCORE_CORRECTIONS.name()));

        final ResultDiscardingRule resultDiscardingRule = leaderboard.getResultDiscardingRule();
        if (resultDiscardingRule != null && resultDiscardingRule instanceof ThresholdBasedResultDiscardingRule) {
            resultDiscardingRuleSerializer.serialize(resultDiscardingRule,
                    target.createAndPutArray(FieldNames.LEADERBOARD_DISCARDING_THRESHOLDS.name()));
        }

        DataArray competitorDisplayNames = target.createAndPutArray(FieldNames.LEADERBOARD_COMPETITOR_DISPLAY_NAMES
                .name());
        for (Competitor competitor : leaderboard.getCompetitors()) {
            String displayNameForCompetitor = leaderboard.getDisplayName(competitor);
            if (displayNameForCompetitor != null) {
                DataObject dbDisplayName = competitorDisplayNames.createAndAddObject();
                dbDisplayName.put(FieldNames.COMPETITOR_ID.name(), competitor.getId());
                dbDisplayName.put(FieldNames.COMPETITOR_DISPLAY_NAME.name(), displayNameForCompetitor);
                competitorDisplayNames.add(dbDisplayName);
            }
        }
    }

    private void storeScoreCorrections(Leaderboard leaderboard, DataObject target) {
        TimePoint now = MillisecondsTimePoint.now();
        SettableScoreCorrection scoreCorrection = leaderboard.getScoreCorrection();
        for (RaceColumn raceColumn : leaderboard.getRaceColumns()) {
            // using the column name as the key for the score corrections requires re-writing the score corrections
            // of a meta-leaderboard if the name of one of its leaderboards changes
            DataArray dbCorrectionForRace = target.createAndPutArray(raceColumn.getName());
            for (Competitor competitor : leaderboard.getCompetitors()) {
                // TODO bug 655: make score corrections time dependent
                if (scoreCorrection.isScoreCorrected(competitor, raceColumn, now)) {
                    DataObject dbCorrectionForCompetitor = dbCorrectionForRace.createAndAddObject();
                    dbCorrectionForCompetitor.put(FieldNames.COMPETITOR_ID.name(), competitor.getId());
                    MaxPointsReason maxPointsReason = scoreCorrection.getMaxPointsReason(competitor, raceColumn, now);
                    if (maxPointsReason != MaxPointsReason.NONE) {
                        dbCorrectionForCompetitor.put(FieldNames.LEADERBOARD_SCORE_CORRECTION_MAX_POINTS_REASON.name(),
                                maxPointsReason.name());
                    }
                    Double explicitScoreCorrection = scoreCorrection.getExplicitScoreCorrection(competitor, raceColumn);
                    if (explicitScoreCorrection != null) {
                        dbCorrectionForCompetitor.put(FieldNames.LEADERBOARD_CORRECTED_SCORE.name(),
                                explicitScoreCorrection);
                    }
                }
            }
            if (dbCorrectionForRace.isEmpty()) {
                target.remove(raceColumn.getName());
            }
        }
        final TimePoint timePointOfLastCorrectionsValidity = scoreCorrection.getTimePointOfLastCorrectionsValidity();
        if (timePointOfLastCorrectionsValidity != null) {
            target.put(FieldNames.LEADERBOARD_SCORE_CORRECTION_TIMESTAMP.name(),
                    timePointOfLastCorrectionsValidity.asMillis());
        }
        if (scoreCorrection.getComment() != null) {
            target.put(FieldNames.LEADERBOARD_SCORE_CORRECTION_COMMENT.name(), scoreCorrection.getComment());
        }
    }

    @Override
    public Leaderboard deserialize(DataObject dbLeaderboard) throws DataDeserializationException {
        throw new UnsupportedOperationException("No money left!");
    }

}
