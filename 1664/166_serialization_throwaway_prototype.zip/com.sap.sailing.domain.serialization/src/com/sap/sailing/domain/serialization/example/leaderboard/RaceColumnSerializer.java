package com.sap.sailing.domain.serialization.example.leaderboard;

import com.sap.sailing.domain.base.Fleet;
import com.sap.sailing.domain.base.RaceColumn;
import com.sap.sailing.domain.common.RaceIdentifier;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.example.FieldNames;

public class RaceColumnSerializer implements DataObjectSerializer<RaceColumn> {
    
    private DataObjectSerializer<RaceIdentifier> raceIdentifierSerializer;

    @Override
    public <R extends DataObject> R serialize(RaceColumn raceColumn, R target) throws DataDeserializationException {
        target.put(FieldNames.LEADERBOARD_COLUMN_NAME.name(), raceColumn.getName());
        target.put(FieldNames.LEADERBOARD_IS_MEDAL_RACE_COLUMN.name(), raceColumn.isMedalRace());
        
        DataObject raceIdentifiersPerFleet = target.createAndPutObject(FieldNames.RACE_IDENTIFIERS.name());
        for (Fleet fleet : raceColumn.getFleets()) {
            RaceIdentifier raceIdentifier = raceColumn.getRaceIdentifier(fleet);
            if (raceIdentifier != null) {
                raceIdentifierSerializer.serialize(raceIdentifier, raceIdentifiersPerFleet.createAndPutObject(fleet.getName()));
            }
        }
        return target;
    }

    @Override
    public RaceColumn deserialize(DataObject object) throws DataDeserializationException {
        // TODO Auto-generated method stub
        return null;
    }

}
