package com.sap.sailing.domain.serialization.example.leaderboard;

import com.sap.sailing.domain.common.RaceIdentifier;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;
import com.sap.sailing.domain.serialization.example.FieldNames;

public class RaceIdentifierSerializer implements DataObjectSerializer<RaceIdentifier> {

    @Override
    public <R extends DataObject> R serialize(RaceIdentifier raceIdentifier, R target) throws DataDeserializationException {
        target.put(FieldNames.EVENT_NAME.name(), raceIdentifier.getRegattaName());
        target.put(FieldNames.RACE_NAME.name(), raceIdentifier.getRaceName());
        return target;
    }

    @Override
    public RaceIdentifier deserialize(DataObject object) throws DataDeserializationException {
        // TODO Auto-generated method stub
        return null;
    }

}
