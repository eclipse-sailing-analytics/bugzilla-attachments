package com.sap.sailing.domain.serialization.example.leaderboard;

import com.sap.sailing.domain.leaderboard.ResultDiscardingRule;
import com.sap.sailing.domain.leaderboard.ThresholdBasedResultDiscardingRule;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataArraySerializer;
import com.sap.sailing.domain.serialization.DataDeserializationException;

public class ResultDiscardingRuleSerializer implements DataArraySerializer<ResultDiscardingRule> {

    @Override
    public <R extends DataArray> R serialize(ResultDiscardingRule resultDiscardingRule, R target)
            throws DataDeserializationException {
        for (int threshold : ((ThresholdBasedResultDiscardingRule) resultDiscardingRule).getDiscardIndexResultsStartingWithHowManyRaces()) {
            target.add(threshold);
        }
        return target;
    }

    @Override
    public ResultDiscardingRule deserialize(DataArray object) throws DataDeserializationException {
        // TODO Auto-generated method stub
        return null;
    }

}
