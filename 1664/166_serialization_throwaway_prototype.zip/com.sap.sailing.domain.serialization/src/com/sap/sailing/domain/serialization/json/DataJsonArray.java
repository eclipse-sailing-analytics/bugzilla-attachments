package com.sap.sailing.domain.serialization.json;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;

public class DataJsonArray implements DataArray {

    public static DataJsonArray parse(String jsonText) throws DataDeserializationException {
        try {
            return DataJsonArray.wrap((JSONArray) new JSONParser().parse(jsonText));
        } catch (ParseException e) {
            throw new DataDeserializationException(e);
        }
    }

    public static DataJsonArray wrap(JSONArray jsonArray) {
        return new DataJsonArray(jsonArray);
    }

    private final JSONArray jsonArray;

    public DataJsonArray() {
        this(new JSONArray());
    }

    protected DataJsonArray(JSONArray jsonArray) {
        this.jsonArray = jsonArray;
    }
    
    public JSONArray getValue() {
        return jsonArray;
    }

    @Override
    public DataObject createAndAddObject() {
        JSONObject object = new JSONObject();
        this.add(object);
        return DataJsonObject.wrap(object);
    }

    @Override
    public DataArray createAndAddArray() {
        JSONArray array = new JSONArray();
        this.add(array);
        return DataJsonArray.wrap(array);
    }

    @Override
    public void add(int index, Object element) {
        jsonArray.add(index, element);
    }

    @Override
    public boolean add(Object e) {
        return jsonArray.add(e);
    }

    @Override
    public boolean addAll(Collection<? extends Object> c) {
        return jsonArray.addAll(c);
    }

    @Override
    public boolean addAll(int index, Collection<? extends Object> c) {
        return jsonArray.addAll(index, c);
    }

    @Override
    public void clear() {
        jsonArray.clear();
    }

    @Override
    public boolean contains(Object o) {
        return jsonArray.contains(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return jsonArray.containsAll(c);
    }

    @Override
    public boolean equals(Object o) {
        return jsonArray.equals(o);
    }

    @Override
    public Object get(int index) {
        return jsonArray.get(index);
    }

    @Override
    public int hashCode() {
        return jsonArray.hashCode();
    }

    @Override
    public int indexOf(Object o) {
        return jsonArray.indexOf(o);
    }

    @Override
    public boolean isEmpty() {
        return jsonArray.isEmpty();
    }

    @Override
    public Iterator<Object> iterator() {
        return jsonArray.iterator();
    }

    @Override
    public int lastIndexOf(Object o) {
        return jsonArray.lastIndexOf(o);
    }

    @Override
    public ListIterator<Object> listIterator() {
        return jsonArray.listIterator();
    }

    @Override
    public ListIterator<Object> listIterator(int index) {
        return jsonArray.listIterator(index);
    }

    @Override
    public Object remove(int index) {
        return jsonArray.remove(index);
    }

    @Override
    public boolean remove(Object o) {
        return jsonArray.remove(o);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return jsonArray.removeAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return jsonArray.retainAll(c);
    }

    @Override
    public Object set(int index, Object element) {
        return jsonArray.set(index, element);
    }

    @Override
    public int size() {
        return jsonArray.size();
    }

    @Override
    public List<Object> subList(int fromIndex, int toIndex) {
        return jsonArray.subList(fromIndex, toIndex);
    }

    @Override
    public Object[] toArray() {
        return jsonArray.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return jsonArray.toArray(a);
    }

    @Override
    public String toString() {
        return jsonArray.toString();
    }

}