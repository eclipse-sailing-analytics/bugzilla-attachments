package com.sap.sailing.domain.serialization.json;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;

public class DataJsonObject implements DataObject {

    public static DataJsonObject parse(String jsonText) throws DataDeserializationException {
        try {
            return DataJsonObject.wrap((JSONObject) new JSONParser().parse(jsonText));
        } catch (ParseException e) {
            throw new DataDeserializationException(e);
        }
    }
    
    public static DataJsonObject wrap(JSONObject jsonObject) {
        return new DataJsonObject(jsonObject);
    }

    private final JSONObject jsonObject;

    public DataJsonObject() {
        this(new JSONObject());
    }

    protected DataJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }
    
    public JSONObject getValue() {
        return jsonObject;
    }

    @Override
    public DataArray createAndPutArray(String fieldName) {
        JSONArray jsonArray = new JSONArray();
        this.put(fieldName, jsonArray);
        return DataJsonArray.wrap(jsonArray);
    }

    @Override
    public DataArray getArray(String fieldName) throws DataDeserializationException {
        Object value = get(fieldName);
        if (value instanceof JSONArray) {
            return new DataJsonArray((JSONArray) value);
        } else {
            throw new DataDeserializationException("This field is not an array.");
        }
    }

    @Override
    public DataObject createAndPutObject(String fieldName) {
        JSONObject inner = new JSONObject();
        this.put(fieldName, inner);
        return new DataJsonObject(inner);
    }

    @Override
    public DataObject getObject(String fieldName) throws DataDeserializationException {
        Object value = get(fieldName);
        if (value instanceof JSONObject) {
            return new DataJsonObject((JSONObject) value);
        } else {
            throw new DataDeserializationException("This field is not an object.");
        }
    }

    @Override
    public int getInteger(String fieldName) throws DataDeserializationException {
        Object number = jsonObject.get(fieldName);
        if (number instanceof Number == false) {
            throw new DataDeserializationException("This field is not a number.");
        }
        return ((Number)number).intValue();
    }

    @Override
    public long getLong(String fieldName) throws DataDeserializationException {
        Object number = jsonObject.get(fieldName);
        if (number instanceof Number == false) {
            throw new DataDeserializationException("This field is not a number.");
        }
        return ((Number)number).longValue();
    }

    @Override
    public String getString(String fieldName) throws DataDeserializationException {
        Object value = jsonObject.get(fieldName);
        if (value instanceof String == false) {
            throw new DataDeserializationException("This field is not a string.");
        }
        return value.toString();
    }

    @Override
    public boolean getBoolean(String fieldName) throws DataDeserializationException {
        Object value = jsonObject.get(fieldName);
        if (value instanceof Boolean == false) {
            throw new DataDeserializationException("This field is not a boolean.");
        }
        return (Boolean) value;
    }

    @Override
    public double getDouble(String fieldName) throws DataDeserializationException {
        Object number = jsonObject.get(fieldName);
        if (number instanceof Double == false) {
            throw new DataDeserializationException("This field is not a number.");
        }
        return ((Number)number).doubleValue();
    }

    @Override
    public void clear() {
        jsonObject.clear();
    }

    @Override
    public boolean containsKey(Object key) {
        return jsonObject.containsKey(key);
    }

    @Override
    public boolean containsValue(Object arg0) {
        return jsonObject.containsValue(arg0);
    }

    @Override
    public Set<Map.Entry<String, Object>> entrySet() {
        Set<Map.Entry<String, Object>> entrySet = new HashSet<Map.Entry<String, Object>>();
        for (Entry<Object, Object> entry : jsonObject.entrySet()) {
            entrySet.add(new AbstractMap.SimpleEntry<String, Object>(entry.getKey().toString(), entry.getValue()));
        }
        return entrySet;
    }

    @Override
    public boolean equals(Object other) {
        return jsonObject.equals(other);
    }

    @Override
    public Object get(Object key) {
        return jsonObject.get(key);
    }

    @Override
    public int hashCode() {
        return jsonObject.hashCode();
    }

    @Override
    public boolean isEmpty() {
        return jsonObject.isEmpty();
    }

    @Override
    public Set<String> keySet() {
        Set<String> keys = new HashSet<String>();
        for (Object key : jsonObject.keySet()) {
            keys.add(key.toString());
        }
        return keys;
    }

    @Override
    public Object put(String key, Object value) {
        return jsonObject.put(key, value);
    }

    @Override
    public void putAll(Map<? extends String, ? extends Object> arg0) {
        jsonObject.putAll(arg0);
    }
    
    @Override
    public Object remove(Object key) {
        return jsonObject.remove(key);
    }

    @Override
    public int size() {
        return jsonObject.size();
    }

    @Override
    public String toString() {
        return jsonObject.toString();
    }

    @Override
    public Collection<Object> values() {
        return jsonObject.values();
    }

}
