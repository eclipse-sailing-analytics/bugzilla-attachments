package com.sap.sailing.domain.serialization.mongodb;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataObject;

/**
 * Backed by a {@link BasicDBList}.
 *
 */
public class DataMongoArray implements DataArray {

    public static DataMongoArray wrap(BasicDBList dbList) {
        return new DataMongoArray(dbList);
    }

    private final BasicDBList dbList;

    public DataMongoArray() {
        this(new BasicDBList());
    }

    protected DataMongoArray(BasicDBList dbList) {
        this.dbList = dbList;
    }

    public BasicDBList getValue() {
        return dbList;
    }

    @Override
    public DataObject createAndAddObject() {
        BasicDBObject inner = new BasicDBObject();
        this.add(inner);
        return new DataMongoObject(inner);
    }

    @Override
    public DataArray createAndAddArray() {
        BasicDBList inner = new BasicDBList();
        this.add(inner);
        return DataMongoArray.wrap(inner);
    }

    @Override
    public void add(int index, Object arg1) {
        dbList.add(index, arg1);
    }

    @Override
    public boolean add(Object arg0) {
        return dbList.add(arg0);
    }

    @Override
    public boolean addAll(Collection<? extends Object> arg0) {
        return dbList.addAll(arg0);
    }

    @Override
    public boolean addAll(int index, Collection<? extends Object> arg1) {
        return dbList.addAll(index, arg1);
    }

    @Override
    public void clear() {
        dbList.clear();
    }

    @Override
    public boolean contains(Object arg0) {
        return dbList.contains(arg0);
    }

    @Override
    public boolean containsAll(Collection<?> arg0) {
        return dbList.containsAll(arg0);
    }

    @Override
    public boolean equals(Object arg0) {
        return dbList.equals(arg0);
    }

    @Override
    public Object get(int index) {
        return dbList.get(index);
    }

    @Override
    public int hashCode() {
        return dbList.hashCode();
    }

    @Override
    public int indexOf(Object arg0) {
        return dbList.indexOf(arg0);
    }

    @Override
    public boolean isEmpty() {
        return dbList.isEmpty();
    }

    @Override
    public Iterator<Object> iterator() {
        return dbList.iterator();
    }

    @Override
    public int lastIndexOf(Object arg0) {
        return dbList.lastIndexOf(arg0);
    }

    @Override
    public ListIterator<Object> listIterator() {
        return dbList.listIterator();
    }

    @Override
    public ListIterator<Object> listIterator(int index) {
        return dbList.listIterator(index);
    }

    @Override
    public Object remove(int index) {
        return dbList.remove(index);
    }

    @Override
    public boolean remove(Object arg0) {
        return dbList.remove(arg0);
    }

    @Override
    public boolean removeAll(Collection<?> arg0) {
        return dbList.removeAll(arg0);
    }

    @Override
    public boolean retainAll(Collection<?> arg0) {
        return dbList.retainAll(arg0);
    }

    @Override
    public Object set(int index, Object endIndex) {
        return dbList.set(index, endIndex);
    }

    @Override
    public int size() {
        return dbList.size();
    }

    @Override
    public List<Object> subList(int index, int endIndex) {
        return dbList.subList(index, endIndex);
    }

    @Override
    public Object[] toArray() {
        return dbList.toArray();
    }

    @Override
    public <T> T[] toArray(T[] arg0) {
        return dbList.toArray(arg0);
    }

    @Override
    public String toString() {
        return dbList.toString();
    }

}
