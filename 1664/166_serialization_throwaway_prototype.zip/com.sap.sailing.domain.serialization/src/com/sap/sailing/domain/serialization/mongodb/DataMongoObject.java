package com.sap.sailing.domain.serialization.mongodb;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.sap.sailing.domain.serialization.DataArray;
import com.sap.sailing.domain.serialization.DataDeserializationException;
import com.sap.sailing.domain.serialization.DataObject;

/**
 * Backed by a {@link BasicDBObject}. Escapes and unescapes field names for you.
 *
 */
public class DataMongoObject implements DataObject {

    public static DataMongoObject wrap(DBObject dbObject) throws DataDeserializationException {
        if (dbObject instanceof BasicDBObject == false) {
            throw new DataDeserializationException("This object is not a " + BasicDBObject.class.getName());
        }
        return DataMongoObject.wrap((BasicDBObject) dbObject);
    }

    public static DataMongoObject wrap(BasicDBObject dbObject) {
        return new DataMongoObject(dbObject);
    }

    private final BasicDBObject dbObject;

    public DataMongoObject() {
        this(new BasicDBObject());
    }

    protected DataMongoObject(BasicDBObject dbObject) {
        this.dbObject = dbObject;
    }

    public BasicDBObject getValue() {
        return dbObject;
    }

    @Override
    public DataArray createAndPutArray(String fieldName) {
        BasicDBList dbList = new BasicDBList();
        dbObject.put(Utils.escape(fieldName), dbList);
        return new DataMongoArray(dbList);
    }

    @Override
    public DataObject createAndPutObject(String fieldName) {
        BasicDBObject inner = new BasicDBObject();
        dbObject.put(Utils.escape(fieldName), inner);
        return new DataMongoObject(inner);
    }

    @Override
    public DataArray getArray(String fieldName) throws DataDeserializationException {
        Object value = get(Utils.escape(fieldName));
        if (value instanceof BasicDBList) {
            return new DataMongoArray((BasicDBList) value);
        } else {
            throw new DataDeserializationException("This field is not an array.");
        }
    }

    @Override
    public DataObject getObject(String fieldName) throws DataDeserializationException {
        Object value = get(Utils.escape(fieldName));
        if (value instanceof BasicDBObject) {
            return new DataMongoObject((BasicDBObject) value);
        } else {
            throw new DataDeserializationException("This field is not an object.");
        }
    }

    @Override
    public int getInteger(String fieldName) throws DataDeserializationException {
        return getInt(fieldName);
    }

    @Override
    public boolean getBoolean(String fieldName) {
        return dbObject.getBoolean(Utils.escape(fieldName));
    }

    @Override
    public double getDouble(String fieldName) {
        return dbObject.getDouble(Utils.escape(fieldName));
    }

    @Override
    public long getLong(String fieldName) {
        return dbObject.getLong(Utils.escape(fieldName));
    }

    @Override
    public String getString(String fieldName) {
        return dbObject.getString(Utils.escape(fieldName));
    }

    @Override
    public void clear() {
        dbObject.clear();
    }

    @Override
    public boolean containsKey(Object fieldName) {
        return dbObject.containsField(Utils.escape(fieldName.toString()));
    }

    @Override
    public boolean containsValue(Object value) {
        return dbObject.containsValue(value);
    }

    @Override
    public Set<Entry<String, Object>> entrySet() {
        Set<Entry<String, Object>> unescapedSet = new HashSet<Map.Entry<String, Object>>();
        for (Entry<String, Object> entry : dbObject.entrySet()) {
            unescapedSet.add(new AbstractMap.SimpleEntry<String, Object>(Utils.unescape(entry.getKey()), entry
                    .getValue()));
        }
        return unescapedSet;
    }

    @Override
    public boolean equals(Object o) {
        return dbObject.equals(o);
    }

    @Override
    public Object get(Object fieldName) {
        return dbObject.get(Utils.escape(fieldName.toString()));
    }

    protected int getInt(String fieldName) {
        return dbObject.getInt(Utils.escape(fieldName));
    }

    @Override
    public int hashCode() {
        return dbObject.hashCode();
    }

    @Override
    public boolean isEmpty() {
        return dbObject.isEmpty();
    }

    @Override
    public Set<String> keySet() {
        Set<String> unescapedKeys = new HashSet<String>();
        for (String key : dbObject.keySet()) {
            unescapedKeys.add(Utils.unescape(key));
        }
        return unescapedKeys;
    }

    @Override
    public Object put(String fieldName, Object val) {
        return dbObject.put(Utils.escape(fieldName), val);
    }

    @Override
    public void putAll(@SuppressWarnings("rawtypes") Map m) {
        for (Object object : m.entrySet()) {
            @SuppressWarnings("unchecked")
            Entry<String, Object> entry = (Entry<String, Object>) object;
            this.put(entry.getKey(), entry.getValue());
        }
    }

    @Override
    public Object remove(Object fieldName) {
        return dbObject.remove(Utils.escape(fieldName.toString()));
    }

    @Override
    public int size() {
        return dbObject.size();
    }

    @Override
    public String toString() {
        return dbObject.toString();
    }

    @Override
    public Collection<Object> values() {
        return dbObject.values();
    }

}
