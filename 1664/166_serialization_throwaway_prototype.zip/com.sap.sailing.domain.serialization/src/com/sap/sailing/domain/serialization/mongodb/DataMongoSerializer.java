package com.sap.sailing.domain.serialization.mongodb;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.sap.sailing.domain.serialization.DataObjectSerializer;

public abstract class DataMongoSerializer<T, R> implements DataObjectSerializer<T> {
    
    public DBObject createUpdate(DBObject update) {
        return new BasicDBObject("$set", update);
    }
    
    public abstract DBObject createQuery(R queryValue);

}
